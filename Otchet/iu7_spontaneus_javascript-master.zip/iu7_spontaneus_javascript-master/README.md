# iu7_spontaneus_javascript
BMSTU, IU7, 5 семестр: Внезапно, Node.js заместо архитектуры ЭВМ (2020).
