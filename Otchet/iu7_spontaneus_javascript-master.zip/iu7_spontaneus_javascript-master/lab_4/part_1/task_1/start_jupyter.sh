#!/bin/bash
jupyter notebook &